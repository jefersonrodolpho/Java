package unidade2;

import javax.swing.JOptionPane;

public class Asset {
    public static void main(String[] args) {
        var time = JOptionPane.showInputDialog("Informe os integrantes da equipe");
        JOptionPane.showMessageDialog(null, "esse é o melhor time do asset " +time);
    }
}
